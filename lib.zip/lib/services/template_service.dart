import '../core/firebase_refs.dart';
import '../models/form_template.dart';

class TemplateService {
  Future<FormTemplate?> fetchActiveTemplate({
    required String roleId,
    required String districtId,
    required String logType,
    String? eventType,
  }) async {
    final et = (eventType == null || eventType.trim().isEmpty)
        ? 'general'
        : eventType.trim();

    // 1) Primary: with eventType
    try {
      final q1 = await templatesRef
          .where('roleId', isEqualTo: roleId)
          .where('districtId', isEqualTo: districtId)
          .where('logType', isEqualTo: logType)
          .where('eventType', isEqualTo: et)
          .where('isActive', isEqualTo: true)
          .orderBy('version', descending: true)
          .limit(1)
          .get();

      if (q1.docs.isNotEmpty) {
        final doc = q1.docs.first;
        return FormTemplate.fromMap(doc.id, doc.data());
      }
    } catch (e) {
      // If Firestore asks for an index, it will throw here.
      // We'll continue to fallback, but you should create the index from the error link.
    }

    // 2) Fallback: without eventType (for older templates)
    final q2 = await templatesRef
        .where('roleId', isEqualTo: roleId)
        .where('districtId', isEqualTo: districtId)
        .where('logType', isEqualTo: logType)
        .where('isActive', isEqualTo: true)
        .orderBy('version', descending: true)
        .limit(1)
        .get();

    if (q2.docs.isEmpty) return null;
    final doc = q2.docs.first;
    return FormTemplate.fromMap(doc.id, doc.data());
  }
}
