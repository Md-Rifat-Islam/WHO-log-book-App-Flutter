import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DynamicInputField extends StatelessWidget {
  final String label;
  final String type; // text, number, date, time, textarea
  final bool requiredField;
  final dynamic initialValue;
  final void Function(dynamic value) onChanged;

  const DynamicInputField({
    super.key,
    required this.label,
    required this.type,
    required this.requiredField,
    required this.initialValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    switch (type) {
      case 'date':
        return _DateField(
          label: label,
          requiredField: requiredField,
          initialValue: initialValue,
          onChanged: onChanged,
        );
      case 'time':
        return _TimeField(
          label: label,
          requiredField: requiredField,
          initialValue: initialValue,
          onChanged: onChanged,
        );
      default:
        return _TextField(
          label: label,
          requiredField: requiredField,
          initialValue: initialValue,
          onChanged: onChanged,
          maxLines: type == 'textarea' ? 4 : 1,
          keyboardType: type == 'number' ? TextInputType.number : TextInputType.text,
        );
    }
  }
}

// --- Text/Number/Textarea Field ---

class _TextField extends StatelessWidget {
  final String label;
  final bool requiredField;
  final dynamic initialValue;
  final void Function(dynamic value) onChanged;
  final TextInputType keyboardType;
  final int maxLines;

  const _TextField({
    required this.label,
    required this.requiredField,
    required this.initialValue,
    required this.onChanged,
    required this.keyboardType,
    required this.maxLines,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        initialValue: initialValue?.toString(),
        maxLines: maxLines,
        keyboardType: keyboardType,
        decoration: _FieldStyle.buildDecoration(label, icon: _getIcon()),
        validator: (v) {
          if (!requiredField) return null;
          if (v == null || v.trim().isEmpty) return 'এই ঘরটি পূরণ করুন';
          return null;
        },
        onChanged: (v) {
          if (keyboardType == TextInputType.number) {
            onChanged(num.tryParse(v) ?? v);
          } else {
            onChanged(v);
          }
        },
      ),
    );
  }

  IconData _getIcon() {
    if (keyboardType == TextInputType.number) return Icons.calculate_outlined;
    if (maxLines > 1) return Icons.notes_rounded;
    return Icons.edit_note_rounded;
  }
}

// --- Date Picker Field ---

class _DateField extends StatefulWidget {
  final String label;
  final bool requiredField;
  final dynamic initialValue;
  final void Function(dynamic value) onChanged;

  const _DateField({required this.label, required this.requiredField, required this.initialValue, required this.onChanged});

  @override
  State<_DateField> createState() => _DateFieldState();
}

class _DateFieldState extends State<_DateField> {
  DateTime? _date;

  @override
  void initState() {
    super.initState();
    if (widget.initialValue is DateTime) {
      _date = widget.initialValue;
    } else if (widget.initialValue != null) {
      _date = DateTime.tryParse(widget.initialValue.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    // Format: 14-Jan-2026
    final text = _date == null ? '' : DateFormat('dd-MMM-yyyy').format(_date!);

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: FormField<String>(
        validator: (_) => widget.requiredField && _date == null ? 'তারিখ নির্বাচন করুন' : null,
        builder: (state) => InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: _date ?? DateTime.now(),
              firstDate: DateTime(2000),
              lastDate: DateTime(2100),
              builder: (context, child) => _FieldStyle.applyTheme(child!),
            );
            if (picked != null) {
              setState(() => _date = picked);
              widget.onChanged(DateFormat('yyyy-MM-dd').format(picked));
              state.didChange(text);
            }
          },
          child: InputDecorator(
            decoration: _FieldStyle.buildDecoration(widget.label, icon: Icons.calendar_today_outlined, errorText: state.errorText),
            child: Text(text.isEmpty ? 'তারিখ নির্বাচন করুন' : text, style: const TextStyle(fontSize: 16)),
          ),
        ),
      ),
    );
  }
}

// --- Time Picker Field ---

class _TimeField extends StatefulWidget {
  final String label;
  final bool requiredField;
  final dynamic initialValue;
  final void Function(dynamic value) onChanged;

  const _TimeField({required this.label, required this.requiredField, required this.initialValue, required this.onChanged});

  @override
  State<_TimeField> createState() => _TimeFieldState();
}

class _TimeFieldState extends State<_TimeField> {
  TimeOfDay? _time;

  @override
  void initState() {
    super.initState();
    final v = widget.initialValue?.toString();
    if (v != null && v.contains(':')) {
      final parts = v.split(':');
      _time = TimeOfDay(hour: int.parse(parts[0]), minute: int.parse(parts[1]));
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = _time?.format(context) ?? '';

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: FormField<String>(
        validator: (_) => widget.requiredField && _time == null ? 'সময় নির্বাচন করুন' : null,
        builder: (state) => InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () async {
            final picked = await showTimePicker(
              context: context,
              initialTime: _time ?? TimeOfDay.now(),
              builder: (context, child) => _FieldStyle.applyTheme(child!),
            );
            if (picked != null) {
              setState(() => _time = picked);
              final v = '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
              widget.onChanged(v);
              state.didChange(v);
            }
          },
          child: InputDecorator(
            decoration: _FieldStyle.buildDecoration(widget.label, icon: Icons.access_time_rounded, errorText: state.errorText),
            child: Text(text.isEmpty ? 'সময় নির্বাচন করুন' : text, style: const TextStyle(fontSize: 16)),
          ),
        ),
      ),
    );
  }
}

// --- Static Style Helper Class ---

class _FieldStyle {
  static const primaryColor = Color(0xFF0B6E69); // WHO Brand Teal

  static InputDecoration buildDecoration(String label, {IconData? icon, String? errorText}) {
    return InputDecoration(
      labelText: label,
      errorText: errorText,
      alignLabelWithHint: true,
      prefixIcon: icon != null ? Icon(icon, color: primaryColor, size: 20) : null,
      labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: primaryColor, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Colors.redAccent, width: 1),
      ),
    );
  }

  static Widget applyTheme(Widget child) {
    return Theme(
      data: ThemeData.light().copyWith(
        colorScheme: const ColorScheme.light(
          primary: primaryColor,
          onPrimary: Colors.white,
          surface: Colors.white,
          onSurface: Colors.black,
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: primaryColor),
        ),
      ),
      child: child,
    );
  }
}