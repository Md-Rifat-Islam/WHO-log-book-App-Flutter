import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../../core/constants.dart';
import '../../../core/firebase_refs.dart';
import '../../../models/app_user.dart';
import '../../../models/form_template.dart';
import '../../../services/template_service.dart';
import '../../../stores/session_store.dart';
import '../widgets/repeater_field.dart';

class DailyLogScreen extends StatefulWidget {
  const DailyLogScreen({super.key});

  @override
  State<DailyLogScreen> createState() => _DailyLogScreenState();
}

class _DailyLogScreenState extends State<DailyLogScreen> {
  final _templateService = TemplateService();
  final _formKey = GlobalKey<FormState>();

  FormTemplate? _template;
  String? _error;
  bool _loading = true;
  bool _submitting = false;

  // This is what will be saved inside logs.data
  // Example:
  // {
  //   "pump_name_or_no": "Pump-01",
  //   "entries": [ {row1...}, {row2...} ]
  // }
  final Map<String, dynamic> _values = {};

  @override
  void initState() {
    super.initState();
    _loadTemplate();
  }

  Future<void> _loadTemplate() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final AppUser? user = SessionStore.instance.currentUser;
      if (user == null) throw StateError('No session user loaded.');

      final districtId = user.districtId;
      if (districtId == null || districtId.isEmpty) {
        throw StateError('districtId missing in user profile.');
      }

      final t = await _templateService.fetchActiveTemplate(
        roleId: user.roleId,
        districtId: districtId,
        logType: LogTypes.daily,
        eventType: EventTypes.general,
      );



      if (!mounted) return;

      setState(() {
        _template = t;
        _loading = false;
        _error = (t == null) ? 'No active Daily template found.' : null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  String _todayPeriodKey(DateTime dt) {
    final y = dt.year.toString().padLeft(4, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final d = dt.day.toString().padLeft(2, '0');
    return '$y-$m-$d'; // e.g. 2026-01-07
  }

  Future<void> _submit() async {
    final t = _template;
    if (t == null) return;

    final ok = _formKey.currentState?.validate() ?? false;
    if (!ok) return;

    final user = SessionStore.instance.currentUser;
    if (user == null) return;

    final now = DateTime.now();
    final periodKey = _todayPeriodKey(now);

    setState(() => _submitting = true);

    try {
      // Duplicate prevention for demo: same user + district + daily + same date
      final existing = await logsRef
          .where('userId', isEqualTo: user.uid)
          .where('logType', isEqualTo: LogTypes.daily)
          .where('periodKey', isEqualTo: periodKey)
          .where('districtId', isEqualTo: user.districtId)
          .limit(1)
          .get();

      if (existing.docs.isNotEmpty) {
        throw StateError('আজকের দৈনিক লগ ইতিমধ্যে জমা হয়েছে ($periodKey).');
      }

      await logsRef.add({
        'userId': user.uid,
        'roleId': user.roleId,
        'districtId': user.districtId,
        'logType': LogTypes.daily,
        'periodKey': periodKey,
        'formTemplateId': t.id,
        'formVersion': t.version,
        'data': _values,
        'status': LogStatus.pending,
        'editable': false,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'lastActionBy': user.uid,
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('দৈনিকলগ সফলভাবে জমা হয়েছে'),
          backgroundColor: Colors.green.shade600,
        ),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Submit failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = SessionStore.instance.currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('Daily Log')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (_error != null)
          ? Padding(
        padding: const EdgeInsets.all(16),
        child: Text(
          'Template load error:\n\n$_error\n\n'
              'Fix: Create an active template in /formTemplates for:\n'
              'roleId=${user?.roleId}, districtId=${user?.districtId}, logType=daily',
        ),
      )
          : _buildForm(),
      bottomNavigationBar: (_template == null)
          ? null
          : Padding(
        padding: const EdgeInsets.all(12),
        child: SizedBox(
          height: 48,
          child: ElevatedButton(
            onPressed: _submitting ? null : _submit,
            child: _submitting
                ? const SizedBox(
              height: 18,
              width: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
                : const Text('Submit / জমা দিন'),
          ),
        ),
      ),
    );
  }

  Widget _buildForm() {
    final t = _template!;
    final header = t.headerFields;
    final fields = t.fields;

    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            t.titleBn,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),

          // Header fields (e.g., pump_name_or_no)
          ...header.map((f) => _buildSimpleField(f, storeIn: _values)),

          const SizedBox(height: 12),

          // Main fields (including repeater/table)
          ...fields.map((f) {
            final type = (f['type'] ?? 'text').toString();

            if (type == 'repeater') {
              // Convention: repeater key is expected to be "entries"
              final repeaterKey = (f['key'] ?? 'entries').toString();
              final label = (f['labelBn'] ?? 'এন্ট্রি').toString();
              final minRows = (f['minRows'] is int) ? (f['minRows'] as int) : 1;

              final colsRaw = f['columns'];
              final cols = (colsRaw is List)
                  ? colsRaw
                  .whereType<Map>()
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList()
                  : <Map<String, dynamic>>[];

              // Ensure we store rows under repeaterKey
              _values[repeaterKey] ??= <Map<String, dynamic>>[];

              return RepeaterField(
                label: label,
                columns: cols,
                minRows: minRows,
                values: _values,
                repeaterKey: repeaterKey,
              );
            }

            return _buildSimpleField(f, storeIn: _values);
          }),

          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _buildSimpleField(
      Map<String, dynamic> f, {
        required Map<String, dynamic> storeIn,
      }) {
    final key = (f['key'] ?? '').toString();
    final labelBn = (f['labelBn'] ?? key).toString();
    final type = (f['type'] ?? 'text').toString();
    final requiredField = f['required'] == true;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: labelBn,
          border: const OutlineInputBorder(),
        ),
        keyboardType:
        (type == 'number') ? TextInputType.number : TextInputType.text,
        validator: (v) {
          if (!requiredField) return null;
          if (v == null || v.trim().isEmpty) return 'এই ঘরটি পূরণ করুন';
          return null;
        },
        onChanged: (v) {
          storeIn[key] = (type == 'number') ? (num.tryParse(v) ?? v) : v;
        },
      ),
    );
  }
}
