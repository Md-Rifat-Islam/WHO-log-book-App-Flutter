import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../../stores/session_store.dart';

// --- DASHBOARD TILE WIDGET ---
class DashTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final String route;
  final Object? extra;
  final Gradient gradient;
  final bool disabled;

  const DashTile({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.route,
    required this.gradient,
    this.extra,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final disabledGradient = LinearGradient(
      colors: [Colors.grey.shade400, Colors.grey.shade500],
    );

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: disabled ? disabledGradient : gradient,
        boxShadow: [
          BoxShadow(
            color: (disabled ? Colors.grey : gradient.colors.last).withOpacity(0.25),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned(
              right: -10,
              bottom: -10,
              child: Icon(
                icon,
                size: 80,
                color: Colors.white.withOpacity(0.12),
              ),
            ),
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: disabled ? null : () {
                  HapticFeedback.lightImpact();
                  context.push(route, extra: extra);
                },
                splashColor: Colors.white.withOpacity(0.2),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(icon, size: 22, color: Colors.white),
                      ),
                      const Spacer(),
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.white.withOpacity(0.9),
                        ),
                      ),
                      if (disabled)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            'শীঘ্রই আসছে',
                            style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(0.7)),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- MAIN DASHBOARD SCREEN ---
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  static const Color tealWater = Color(0xFF0B6E69);
  static const Color bgColor = Color(0xFFF7F8FA);

  @override
  Widget build(BuildContext context) {
    final user = SessionStore.instance.currentUser;

    // Gradients for the tiles
    const dailyGradient = LinearGradient(colors: [Color(0xFF0B6E69), Color(0xFF07524E)]);
    const historyGradient = LinearGradient(colors: [Color(0xFF14A098), Color(0xFF0B6E69)]);
    const alertGradient = LinearGradient(colors: [Color(0xFFE67E22), Color(0xFFD35400)]);
    const supportGradient = LinearGradient(colors: [Color(0xFF2C3E50), Color(0xFF000000)]);

    return Scaffold(
      backgroundColor: bgColor,
      body: CustomScrollView(
        slivers: [
          // 1. Premium Header with Profile
          SliverAppBar(
            expandedHeight: 180,
            floating: false,
            pinned: true,
            backgroundColor: tealWater,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  // Decorative background circles
                  Positioned(
                    top: -50,
                    right: -50,
                    child: CircleAvatar(radius: 100, backgroundColor: Colors.white.withOpacity(0.05)),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 60, 20, 0),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 35,
                          backgroundColor: Colors.white24,
                          child: Text(
                            user?.name?.substring(0, 1).toUpperCase() ?? 'U',
                            style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ),
                        const SizedBox(width: 15),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'স্বাগতম, ${user?.name ?? 'ব্যবহারকারী'}',
                              style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                            ),
                            Text(
                              'জেলা: ${user?.districtId ?? 'N/A'}',
                              style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 14),
                            ),
                          ],
                        ),
                        const Spacer(),
                        IconButton(
                          onPressed: () {},
                          icon: const Icon(Icons.notifications_active_outlined, color: Colors.white),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 2. Dashboard Grid
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverGrid.count(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.1,
              children: [
                const DashTile(
                  title: 'দৈনিক লগ',
                  subtitle: 'Daily Report',
                  icon: Icons.assignment_rounded,
                  route: '/daily-log',
                  gradient: dailyGradient,
                ),
                const DashTile(
                  title: 'ইতিহাস',
                  subtitle: 'Log History',
                  icon: Icons.manage_search_rounded,
                  route: '/history',
                  gradient: historyGradient,
                ),
                const DashTile(
                  title: 'বন্যা রিপোর্ট',
                  subtitle: 'Flood Data',
                  icon: Icons.tsunami_rounded,
                  route: '/flood-report',
                  gradient: alertGradient,
                ),
                const DashTile(
                  title: 'সহায়তা',
                  subtitle: 'Support',
                  icon: Icons.help_outline_rounded,
                  route: '/support',
                  gradient: supportGradient,
                  disabled: true,
                ),
              ],
            ),
          ),

          // 3. Quick Stats Title
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Text(
                'সাম্প্রতিক অবস্থা (Recent Stats)',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: tealWater),
              ),
            ),
          ),

          // 4. Horizontal Quick Stats (Cards)
          SliverToBoxAdapter(
            child: SizedBox(
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.only(left: 20),
                children: [
                  _miniStatCard('জমা হয়েছে', '১২', Colors.blue),
                  _miniStatCard('অনুমোদিত', '১০', Colors.green),
                  _miniStatCard('পেন্ডিং', '০২', Colors.orange),
                ],
              ),
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 50)),
        ],
      ),
    );
  }

  Widget _miniStatCard(String label, String value, Color color) {
    return Container(
      width: 130,
      margin: const EdgeInsets.only(right: 12, bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      ),
    );
  }
}