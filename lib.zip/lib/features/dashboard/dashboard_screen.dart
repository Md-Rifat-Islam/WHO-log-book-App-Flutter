import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../models/app_user.dart';
import '../../services/auth_service.dart';
import '../../stores/session_store.dart';
import '../../core/constants.dart';
import '../../services/template_service.dart';
import 'dashboard_tile.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  static const Color tealWater = Color(0xFF0B6E69);
  static const Color bgColor = Color(0xFFF7F8FA);

  // --- 1. VIBRANT GRADIENTS ---
  Gradient _getLogTypeGradient(String logType) {
    switch (logType) {
      case LogTypes.daily:
        return const LinearGradient(
          colors: [Color(0xFF2196F3), Color(0xFF00BCD4)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        );
      case LogTypes.weekly:
        return const LinearGradient(
          colors: [Color(0xFFFF9800), Color(0xFFFFC107)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        );
      case LogTypes.monthly:
        return const LinearGradient(
          colors: [Color(0xFF4CAF50), Color(0xFF8BC34A)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        );
      case LogTypes.quarterly:
        return const LinearGradient(
          colors: [Color(0xFFE91E63), Color(0xFFFF5252)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        );
      default:
        return LinearGradient(
          colors: [Colors.blueGrey.shade600, Colors.blueGrey.shade800],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        );
    }
  }

  // --- 2. LOGOUT DIALOG ---
  Future<bool?> _showLogoutDialog(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('লগ আউট?', style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text('আপনি কি নিশ্চিত যে আপনি লগ আউট করতে চান?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('না', style: TextStyle(color: Colors.grey))
          ),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('হ্যাঁ', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold))
          ),
        ],
      ),
    );
  }

  // --- 3. TEMPLATE LOGIC ---
  Future<bool> _templateExists({
    required AppUser user,
    required String logType,
    required String eventType,
  }) async {
    try {
      final template = await TemplateService().fetchActiveTemplate(
        roleId: user.roleId,
        districtId: user.districtId ?? '',
        logType: logType,
        eventType: eventType,
      );
      return template != null;
    } catch (_) { return false; }
  }

  Future<List<_DashBtn>> _buildButtons(AppUser user) async {
    final buttons = <_DashBtn>[];
    final isAdmin = user.roleId.toLowerCase() == 'admin';
    final canApprove = user.permissions['canApprove'] == true;
    const eventType = EventTypes.general;

    Future<void> addLogBtn(String title, String subtitle, IconData icon, String logType) async {
      final exists = await _templateExists(user: user, logType: logType, eventType: eventType);
      if (exists) {
        buttons.add(_DashBtn(
          title: title,
          subtitle: subtitle,
          icon: icon,
          route: '/log',
          gradient: _getLogTypeGradient(logType),
          extra: {'logType': logType, 'eventType': eventType},
        ));
      }
    }

    await Future.wait([
      addLogBtn('Daily', 'দৈনিক লগ', Icons.today, LogTypes.daily),
      addLogBtn('Weekly', 'সাপ্তাহিক লগ', Icons.view_week, LogTypes.weekly),
      addLogBtn('Monthly', 'মাসিক লগ', Icons.calendar_month, LogTypes.monthly),
      addLogBtn('Quarterly', 'ত্রৈমাসিক লগ', Icons.date_range, LogTypes.quarterly),
    ]);

    buttons.add(_DashBtn(
      title: 'History',
      subtitle: 'জমা দেওয়া লগ',
      icon: Icons.history,
      route: '/history',
      gradient: LinearGradient(colors: [Colors.blueGrey.shade600, Colors.blueGrey.shade900]),
    ));

    if (isAdmin || (user.roleId.toLowerCase() == 'supervisor' && canApprove)) {
      buttons.add(_DashBtn(
        title: 'Review',
        subtitle: 'লগ যাচাইকরণ',
        icon: Icons.verified_user_outlined,
        route: '/review',
        gradient: const LinearGradient(colors: [Color(0xFF2C3E50), Color(0xFF000000)]),
      ));
    }
    return buttons;
  }

  @override
  Widget build(BuildContext context) {
    final user = SessionStore.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('User session not found')));

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFFF5F5F5),
        foregroundColor: Colors.black87,
        elevation: 0.5,
        toolbarHeight: 95,
        centerTitle: false,
        title: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.white,
              child: ClipOval(
                child: Image.asset(
                  'assets/images/app_logo.png',
                  fit: BoxFit.cover,
                  width: 40,
                  height: 40,
                  errorBuilder: (context, error, stackTrace) => const Icon(
                      Icons.water_drop_rounded,
                      color: tealWater,
                      size: 28
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'WHO Logbook',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      letterSpacing: -0.5,
                    ),
                  ),
                  Text(
                    user.name,
                    style: TextStyle(fontSize: 13, color: Colors.black.withOpacity(0.7)),
                  ),
                  Text(
                    '(${user.districtId})',
                    style: TextStyle(fontSize: 10, color: Colors.black.withOpacity(0.6)),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Badge(
              label: const Text('!', style: TextStyle(color: Colors.white, fontSize: 10)),
              backgroundColor: tealWater,
              child: const Icon(Icons.notifications_none_rounded, size: 30),
            ),
            onPressed: () => context.push('/notifications'),
          ),
          IconButton(
            icon: const Icon(Icons.power_settings_new_rounded, size: 30),
            onPressed: () async {
              final confirm = await _showLogoutDialog(context);
              if (confirm == true) {
                SessionStore.instance.currentUser = null;
                await AuthService().signOut();
                if (context.mounted) context.go('/login');
              }
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: FutureBuilder<List<_DashBtn>>(
        future: _buildButtons(user),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            // --- UPDATED BRANDED LOADING STATE ---
            return _buildBrandedLoader();
          }
          final buttons = snapshot.data ?? [];
          return GridView.builder(
            padding: const EdgeInsets.all(20),
            itemCount: buttons.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.0,
            ),
            itemBuilder: (context, i) {
              final b = buttons[i];
              return DashTile(
                title: b.title,
                subtitle: b.subtitle,
                icon: b.icon,
                route: b.route,
                extra: b.extra,
                gradient: b.gradient,
              );
            },
          );
        },
      ),
    );
  }

  // --- BRANDED LOADER COMPONENT ---
  Widget _buildBrandedLoader() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                )
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/app_logo.png',
                width: 100,
                height: 100,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => const Icon(
                  Icons.water_drop_rounded,
                  color: tealWater,
                  size: 30,
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          const CircularProgressIndicator(
            color: tealWater,
            strokeWidth: 3,
          ),
          const SizedBox(height: 16),
          Text(
            'তথ্য লোড হচ্ছে...',
            style: TextStyle(
              color: tealWater.withOpacity(0.7),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _DashBtn {
  final String title, subtitle, route;
  final IconData icon;
  final Gradient gradient;
  final Map<String, dynamic>? extra;
  _DashBtn({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.route,
    required this.gradient,
    this.extra
  });
}